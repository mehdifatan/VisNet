"""
VisNet: A biologically-inspired hierarchical vision network library.

This library implements various VisNet architectures based on the Rolls 2015 paper,
including VisNet-MD (Manhattan Distance learning), VisNet-LI (Local Inhibition),
and their variants with different preprocessing (DoG filters, RBF activation).
"""

__version__ = "1.0.0"

from .models import (
    VisNetMDLinear,
    VisNetRBFMD,
    SimplifiedVisNetLI,
    SimplifiedVisNetLIDoG,
    SimplifiedVisNetLIRBF,
    SimplifiedVisNet
)

from .utils import (
    create_gabor_filters,
    create_dog_filter,
    apply_local_inhibition_and_sparseness,
    setup_manhattan_learning,
    setup_oja_learning
)

from .experiments import ExperimentRunner, run_experiment

__all__ = [
    'VisNetMDLinear',
    'VisNetRBFMD',
    'SimplifiedVisNetLI',
    'SimplifiedVisNetLIDoG',
    'SimplifiedVisNetLIRBF',
    'SimplifiedVisNet',
    'create_gabor_filters',
    'create_dog_filter',
    'apply_local_inhibition_and_sparseness',
    'setup_manhattan_learning',
    'setup_oja_learning',
    'ExperimentRunner',
    'run_experiment',
]

