"""
Utility functions for VisNet.
"""

from .filters import create_gabor_filters, create_dog_filter
from .inhibition import apply_local_inhibition_and_sparseness
from .learning import setup_manhattan_learning, setup_oja_learning

__all__ = [
    'create_gabor_filters',
    'create_dog_filter',
    'apply_local_inhibition_and_sparseness',
    'setup_manhattan_learning',
    'setup_oja_learning',
]

