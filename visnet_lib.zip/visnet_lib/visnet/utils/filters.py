"""
Filter implementations for VisNet (Gabor and DoG filters).
"""

import numpy as np
import torch
import torch.nn.functional as F


def gabor_kernel(frequency, theta, sigma=1, lambd=1, gamma=0.5, psi=0):
    """Create a single Gabor filter kernel."""
    sigma_x = sigma
    sigma_y = float(sigma) / gamma
    xmax = max(abs(sigma_x * np.cos(theta)), abs(sigma_y * np.sin(theta)))
    xmax = np.ceil(max(1, xmax))
    ymax = max(abs(sigma_x * np.sin(theta)), abs(sigma_y * np.cos(theta)))
    ymax = np.ceil(max(1, ymax))
    xmin = -xmax
    ymin = -ymax
    (y, x) = np.meshgrid(np.arange(ymin, ymax + 1), np.arange(xmin, xmax + 1))
    x_theta = x * np.cos(theta) + y * np.sin(theta)
    y_theta = -x * np.sin(theta) + y * np.cos(theta)
    gb = np.exp(-0.5 * (x_theta**2 / sigma_x**2 + y_theta**2 / sigma_y**2))
    gb *= np.cos(2 * np.pi / lambd * x_theta + psi)
    return gb


def normalize_kernel(kernel):
    """Normalize kernel to unit L1 norm."""
    return kernel / np.sum(np.abs(kernel))


def create_gabor_filters(frequencies=None, orientations=None, phases=None, fixed_size=21):
    """
    Generate Gabor filters with fixed size.
    
    Args:
        frequencies: List of frequencies (default: [0.5, 0.25, 0.125, 0.0625])
        orientations: List of orientations in radians (default: [0, π/4, π/2, 3π/4])
        phases: List of phases (default: [1.0])
        fixed_size: Size of each filter kernel (default: 21)
    
    Returns:
        List of Gabor filter kernels
    """
    if frequencies is None:
        frequencies = [0.5, 0.25, 0.125, 0.0625]
    if orientations is None:
        orientations = [0, np.pi/4, np.pi/2, 3*np.pi/4]
    if phases is None:
        phases = [1.0]
    
    filters = []
    for frequency in frequencies:
        for theta in orientations:
            for psi in phases:
                kernel = gabor_kernel(frequency=frequency, theta=theta, psi=psi)
                kernel = normalize_kernel(kernel)
                
                # Pad or crop to fixed size
                h, w = kernel.shape
                if h < fixed_size or w < fixed_size:
                    pad_h = (fixed_size - h) // 2
                    pad_w = (fixed_size - w) // 2
                    kernel = np.pad(kernel, ((pad_h, fixed_size - h - pad_h), 
                                            (pad_w, fixed_size - w - pad_w)), 
                                   mode='constant', constant_values=0)
                elif h > fixed_size or w > fixed_size:
                    start_h = (h - fixed_size) // 2
                    start_w = (w - fixed_size) // 2
                    kernel = kernel[start_h:start_h+fixed_size, start_w:start_w+fixed_size]
                
                filters.append(kernel)
    return filters


def create_dog_filter(sigma1=1.0, sigma2=1.2, size=7, device='cpu'):
    """
    Create a Difference of Gaussian (DoG) filter.
    
    Args:
        sigma1: First Gaussian sigma (default: 1.0)
        sigma2: Second Gaussian sigma (default: 1.2)
        size: Filter size (default: 7)
        device: Device to create filter on (default: 'cpu')
    
    Returns:
        DoG filter tensor of shape [1, 1, size, size]
    """
    x = torch.arange(-(size//2), size//2 + 1, dtype=torch.float32, device=device)
    y = torch.arange(-(size//2), size//2 + 1, dtype=torch.float32, device=device)
    X, Y = torch.meshgrid(x, y, indexing='ij')
    r2 = X**2 + Y**2
    g1 = torch.exp(-r2 / (2 * sigma1**2)) / (2 * np.pi * sigma1**2)
    g2 = torch.exp(-r2 / (2 * sigma2**2)) / (2 * np.pi * sigma2**2)
    dog = g1 - 0.6 * g2
    dog = dog / torch.sum(torch.abs(dog))
    return dog.unsqueeze(0).unsqueeze(0)

